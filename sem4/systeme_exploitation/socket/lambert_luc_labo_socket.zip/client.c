#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "common.h"


int main(int argc, char *argv[]){

    //Check number of input args
    if(argc != 3) {
        fprintf(stderr, "Usage:\n\t%s addr_IPv4 port\n", argv[0]);
        return 1;
    }

    // Crée un socket
    int socket_client = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_client == -1)
        die("socket");

    // Connecte un socket à un serveur
    struct sockaddr_in address;
    memset( &address, 0, sizeof(address) );
    inet_pton( AF_INET, argv[1], &(address.sin_addr) );
    address.sin_family = AF_INET;
    address.sin_port = htons(string_to_port(argv[2]));

    int c = connect(socket_client, (struct sockaddr *) &address, sizeof(address));
    if (c==-1)
        die("connect");

    // Lecture/Ecriture à parir du socket (read/write)
    void* buff;
    read_full(socket_client, buff, sizeof(initmsg_t)); 

    initmsg_t* msg = (initmsg_t*)buff;
    msg_t* r;

    //play
    do{
        int val=msg->min-1;
        while (val<msg->min || val>msg->max) {
            printf("find the number between %d and %d : ",msg->min, msg->max);

            if(scanf(" %d", &val)<0){
                die("scanf");
            }
            if (val < msg->min) {
                printf("value too low : %d\n", val);
            }else if(val > msg->max){
                printf("value too high : %d\n", val);
            }
        }
        msg_t m={255,val};
        write_full(socket_client, (void*)&m, sizeof(msg_t));
        printf("Proposition envoyée : %d\n",m.value);

        void* buff2;
        read_full(socket_client, buff2, sizeof(msg_t)); 
        r = (msg_t*)buff2;
        printf("La valeur réelle est : %d\n", r->value);
        switch (r->cmd) {
            case -1:
                printf("TOO LOW\n");
                break;
            case 1:
                printf("TOO HIGH\n");
                break;
            case 0:
                printf("WIN\n");
                break;
            case 2:
                printf("LOSE\n");
                break;
        }
        printf("\n");
    } while (r->cmd != 0 && r->cmd != 2);

    // Ferme le socket (close)
    if(close(socket_client)==-1)
        die("close");

    return 0;
}