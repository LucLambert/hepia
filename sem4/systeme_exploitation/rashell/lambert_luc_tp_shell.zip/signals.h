#ifndef _SIGNALS_H
#define _SIGNALS_H
    #include <signal.h>
    #include "common.h"
    #include <sys/wait.h>
    #include "interface.h"
    #include <signal.h>
    #include <stdio.h>

    /**
    * Init struct sigaction to ignore SIGTERM and SIGQUIT signals
    * and set handler for SIGINT,SIGHUP and SIGCHLD 
    */
    void signals_init();

    /**
    * remove previously added child pid. 
    * @param p child process pid
    */
    void signals_remove_p_childs(pid_t p);

    /**
    * add child pid to static global tab of pid wich will be used to destroy all childs on close.
    * @param p child process pid
    */
    void signals_add_p_childs(pid_t p);

    /**
    * set static global variable p_state equal to p. It will be used to handle process death.
    * @param p child process pid
    */
    void signals_set_p_state(pid_t p);

    /**
    * send signals SIGHUP to all childs added previously. 
    */
    void signals_kill_all_childs();

    /**
    * add child background pid to static global tab of pid wich will be used to handle background job.
    * @param p child process pid
    */
    void signals_add_background_childs(pid_t p);

    /**
    * @return nbr of childs process in background
    */
    int signals_background_childs_nbr();
    
#endif 