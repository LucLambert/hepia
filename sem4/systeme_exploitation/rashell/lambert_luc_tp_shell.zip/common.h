#ifndef _COMMON_H
#define _COMMON_H

    #include <stdio.h>
    #include <stdlib.h>
    #include <errno.h>
    #include "signals.h"
    
    //equivalent to a function that would do perror and exit
    //The do /while is a trick so that the macro can be executed in all kind of context
    //(e.g. in a if without brackets)
    #define die_errno(msg) do { int err=errno; perror(msg); signals_kill_all_childs(); exit(err); } while (0)

#endif