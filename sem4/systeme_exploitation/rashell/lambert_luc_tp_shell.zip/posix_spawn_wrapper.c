#include "posix_spawn_wrapper.h"

static cmd_t* cm;

/**
* same as posix_spawn_init but handle errors. except cmd_t param used to destroy cmd on erro 
* @param cmd actual command to destroy on error.
*/
void posix_spawn_wrapper_init(posix_spawn_file_actions_t* file_actions, posix_spawnattr_t* attr, cmd_t* cmd){
    if(posix_spawn_file_actions_init(file_actions)!=0){
        dispose_command(cmd);
        die_errno("failed posix spawn file action init");
    }
    if(posix_spawnattr_init(attr)!=0){
        dispose_command(cmd);
        die_errno("failed posix spawn attribut init");
    }
    cm = cmd;
}

/**
* same as posix_spawn_file_actions_destroy but handle errors.
*/
void posix_spawn_wrapper_file_actions_destroy(posix_spawn_file_actions_t* file_actions){
    if(posix_spawn_file_actions_destroy(file_actions)!=0)
            die_errno("failed posix spawn file action destroy");
}

/**
* same as posix_spawn_file_actions_addopen but handle errors.
*/
void posix_spawn_wrapper_file_actions_addopen(posix_spawn_file_actions_t* file_actions, int fd, const char *restrict __path, int flags, mode_t mode){
    if(posix_spawn_file_actions_addopen(file_actions, fd, __path, flags, mode)!=0){
        dispose_command(cm);
        posix_spawn_wrapper_file_actions_destroy(file_actions);
        die_errno("failed posix spawn file action add open");
    } 
}

/**
* same as posix_spawn_file_actions_adddup2 but handle errors.
*/
void posix_spawn_wrapper_file_actions_adddup2(posix_spawn_file_actions_t *__file_actions,int __fd, int __newfd){
    if(posix_spawn_file_actions_adddup2(__file_actions, __fd,__newfd)!=0){
        dispose_command(cm);
        posix_spawn_wrapper_file_actions_destroy(__file_actions);
        die_errno("failed posix spawn file action add dup2");
    }
}

/**
* same as posix_spawn_file_actions_addclose but handle errors.
*/
void posix_spawn_wrapper_file_actions_addclose(posix_spawn_file_actions_t *__file_actions,int __fd){
    if(posix_spawn_file_actions_addclose(__file_actions,__fd)!=0){
        dispose_command(cm);
        posix_spawn_wrapper_file_actions_destroy(__file_actions);
        die_errno("failed posix spawn file action add dup2");
    }
}

/**
* same as posix_spawnp but handle errors.
*/
void posix_spawnp_wrapper(pid_t *__pid, const char *__file,
                        const posix_spawn_file_actions_t *__file_actions,
                        const posix_spawnattr_t *__attrp, char *const __argv[],
                        char *const __envp[]){
    int status = 0;
    if((status=posix_spawnp(__pid, __file, __file_actions, __attrp, __argv, __envp))!=0){
        dispose_command(cm);
        posix_spawn_wrapper_file_actions_destroy((posix_spawn_file_actions_t*)__file_actions);
        if (status == 2) {
            *__pid = 0;
            perror("failed posix spawn");
        }else{
            die_errno("failed posix spawn");
        }
    }
}