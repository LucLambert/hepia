#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <spawn.h>
#include <sys/wait.h>
#include <string.h>
#include <pwd.h>
#include <fcntl.h>
#include <unistd.h>
#include "interface.h"
#include "common.h"
#include "posix_spawn_wrapper.h"
#include "signals.h"

int main(){

    signals_init();

    while(1){
        pid_t p, p_background;
        cmd_t c;
        posix_spawn_file_actions_t file_actions;
        posix_spawnattr_t attr;
        int wstatus;
        char buff[4096];
        int ask_status;

        // get command of user
        if((ask_status=ask_user_input(buff)) == -1)
            die_errno("failed ask user input");
        else if (ask_status == 0)
            continue;

        if(parse_command(buff, &c)==-1){
            dispose_command(&c);
            die_errno("parse failed");
        }
        
        // handle built-in command exit and cd
        if (strcmp(c.argv[0],"exit")==0) { // exit
            dispose_command(&c);
            signals_kill_all_childs();
            exit(EXIT_SUCCESS);
        }
        else if (strcmp(c.argv[0],"cd")==0) { // cd
            if (c.argc > 2) {
                dispose_command(&c);
                fprintf(stderr, "rashell: cd: too many arguments\n");
                signals_kill_all_childs();
                exit(EXIT_FAILURE);
                
            }else if(c.argv[1] == NULL){ // go to user root
                uid_t uid = getuid();
                struct passwd * pw = getpwuid(uid);
                if(chdir(pw->pw_dir)==-1)
                    die_errno("chdir failed");
                dispose_command(&c);
            }else{
                if(chdir(c.argv[1])==-1)
                    die_errno("chdir failed");
                dispose_command(&c);
            }
        }else{ 
            //init posix spawn
            posix_spawn_wrapper_init(&file_actions, &attr, &c);

            if (c.type==CMD_SIMPLE) { // handle job command 
                if(!c.foreground){ // background command
                    if (signals_background_childs_nbr()>0) {
                        printf("too much background process\n");
                        dispose_command(&c);
                        continue;
                    }

                    //redirect STDIN to /dev/null
                    posix_spawn_wrapper_file_actions_addopen(&file_actions, STDIN_FILENO, "/dev/null", O_RDONLY, 0);
                    
                    // fork and execute a command with posix spawn
                    posix_spawnp_wrapper(&p_background, c.argv[0], &file_actions, &attr, c.argv, __environ);
                    
                    if (p_background==0) {
                        continue;
                    }
                    //set childs state to handle death
                    signals_add_p_childs(p_background);
                    signals_add_background_childs(p_background);
                    

                    //destroy cmd
                    dispose_command(&c);
                    posix_spawn_wrapper_file_actions_destroy(&file_actions);

                }else{ // foreground command

                    // fork and execute a command with posix spawn
                    posix_spawnp_wrapper(&p, c.argv[0], &file_actions, &attr, c.argv, __environ);

                    if (p==0) {
                        continue;
                    }
                    //set childs state to handle death
                    signals_set_p_state(p);
                    signals_add_p_childs(p);

                    //wait end of cmd
                    do {
                        if(waitpid(p, &wstatus, WUNTRACED | WCONTINUED)==-1){
                            die_errno("failed wait pid");
                        }
                    }while (!WIFEXITED(wstatus) && !WIFSIGNALED(wstatus) && !WIFSTOPPED(wstatus) && !WCOREDUMP(wstatus));
                    

                    if (p!=0) {
                        if (WIFEXITED(wstatus)) {
                            printf("Foreground job exited with code %d\n",WEXITSTATUS(wstatus));
                        }
                    }
                    //set childs state to handle death
                    signals_remove_p_childs(p);
                    //destroy cmd
                    dispose_command(&c);
                    posix_spawn_wrapper_file_actions_destroy(&file_actions);

                }
            }
            else if (c.type==CMD_FILEOUT || c.type==CMD_FILEAPPEND || c.type==CMD_FILEIN) { // handle redirection
                int flags;
                int mode;
                int fd=STDOUT_FILENO;
                //check redirection file exist and writeable
                int status = access(c.argv2[0], F_OK | W_OK | R_OK);
                if(status==0){
                    //file exist
                    mode=0;
                    if (c.type==CMD_FILEAPPEND) {
                        flags=O_APPEND | O_WRONLY;
                    }else if (c.type==CMD_FILEOUT){
                        flags=O_WRONLY;
                    }
                }
                else if (status==-1) {
                    if(errno==ENOENT){ //file doesn't exist
                        mode=S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH;
                        flags=O_CREAT | O_WRONLY;
                    }else{ // access error
                        die_errno("failed access");
                    }
                }
                if (c.type==CMD_FILEIN) {
                    flags=O_RDONLY;
                    mode=0;
                    fd=STDIN_FILENO;
                }
                // redirect child to fd
                posix_spawn_wrapper_file_actions_addopen(&file_actions, fd, c.argv2[0], flags, mode);

                // fork and execute a command with posix spawn
                posix_spawnp_wrapper(&p, c.argv[0], &file_actions, &attr, c.argv, __environ);
                
                if (p==0) {
                    continue;
                }
                //set childs state to handle death
                signals_set_p_state(p);
                signals_add_p_childs(p);

                //wait end of cmd
                do {
                    if(waitpid(p, &wstatus, WUNTRACED | WCONTINUED)==-1){
                        die_errno("failed wait pid");
                    }
                }while (!WIFEXITED(wstatus) && !WIFSIGNALED(wstatus) && !WIFSTOPPED(wstatus) && !WCOREDUMP(wstatus));
                    

                //set childs state to handle death
                signals_remove_p_childs(p);
                //destroy cmd
                dispose_command(&c);
                posix_spawn_wrapper_file_actions_destroy(&file_actions);
                        
                if (p!=0) {
                    if (WIFEXITED(wstatus)) {
                        printf("Foreground job exited with code %d\n",WEXITSTATUS(wstatus));
                    }
                }
            }
            else if (c.type==CMD_PIPE) { // handle pipe
                pid_t p_r;
                posix_spawn_file_actions_t file_actions_r;
                posix_spawnattr_t attr_r;
                int wstatus_r;
                int pipefd[2];

                //init posix spawn 2 commands
                posix_spawn_wrapper_init(&file_actions, &attr, &c);
                posix_spawn_wrapper_init(&file_actions_r, &attr_r, &c);

                //create pipe
                if(pipe2(pipefd, O_CLOEXEC)==-1)
                    die_errno("failed pipe");
                
                //duplicate descriptor table and close 
                posix_spawn_wrapper_file_actions_adddup2(&file_actions,pipefd[1],STDOUT_FILENO);
                posix_spawn_wrapper_file_actions_addclose(&file_actions,pipefd[0]);
                posix_spawn_wrapper_file_actions_addclose(&file_actions,pipefd[1]);

                // fork and execute a command with posix spawn
                posix_spawnp_wrapper(&p, c.argv[0], &file_actions, &attr, c.argv, __environ);

                if (p==0) {
                    continue;
                }

                //set childs state to handle death
                signals_set_p_state(p);
                signals_add_p_childs(p);

                //duplicate descriptor table and close 
                posix_spawn_wrapper_file_actions_adddup2(&file_actions_r,pipefd[0],STDIN_FILENO);
                posix_spawn_wrapper_file_actions_addclose(&file_actions_r,pipefd[0]);
                posix_spawn_wrapper_file_actions_addclose(&file_actions_r,pipefd[1]);

                // fork and execute a command with posix spawn
                posix_spawnp_wrapper(&p_r, c.argv2[0], &file_actions_r, &attr_r, c.argv2, __environ);

                if (p_r==0) {
                    continue;
                }

                //set childs state to handle death
                signals_add_p_childs(p_r);
                
                //closes fd 
                if(close(pipefd[0])==-1)
                    die_errno("failed close");
                if(close(pipefd[1])==-1)
                    die_errno("failed close");

                //wait end of command 1
                do {
                    if(waitpid(p, &wstatus, WUNTRACED | WCONTINUED)==-1)
                        die_errno("failed wait pid");
                }while (!WIFEXITED(wstatus) && !WIFSIGNALED(wstatus) && !WIFSTOPPED(wstatus) && !WCOREDUMP(wstatus));
                
                //set childs state to handle death
                signals_set_p_state(p_r);
                signals_remove_p_childs(p);

                //wait end of command 2
                do {
                    if(waitpid(p_r, &wstatus_r, WUNTRACED | WCONTINUED)==-1)
                        die_errno("failed wait pid");
                }while (!WIFEXITED(wstatus_r) && !WIFSIGNALED(wstatus_r) && !WIFSTOPPED(wstatus_r) && !WCOREDUMP(wstatus_r));
                
                //set childs state to handle death
                signals_remove_p_childs(p_r);

                //destroy cmd 1 and 2
                posix_spawn_wrapper_file_actions_destroy(&file_actions);
                posix_spawn_wrapper_file_actions_destroy(&file_actions_r);
                dispose_command(&c);
            }
        }
    }
}