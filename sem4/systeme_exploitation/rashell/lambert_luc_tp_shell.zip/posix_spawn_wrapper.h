#ifndef _POSIX_SPAWN_WRAPPER_H
#define _POSIX_SPAWN_WRAPPER_H
    
    #include <spawn.h>
    #include "common.h"
    #include "interface.h"
    #include <sys/types.h>

    /**
    * same as posix_spawn_init but handle errors. except cmd_t param used to destroy cmd on erro 
    * @param cmd actual command to destroy on error.
    */
    void posix_spawn_wrapper_init(posix_spawn_file_actions_t* file_actions, posix_spawnattr_t* attr, cmd_t* cmd);
    /**
    * same as posix_spawn_file_actions_destroy but handle errors.
    */
    void posix_spawn_wrapper_file_actions_destroy(posix_spawn_file_actions_t* file_actions);
    /**
    * same as posix_spawn_file_actions_addopen but handle errors.
    */
    void posix_spawn_wrapper_file_actions_addopen(posix_spawn_file_actions_t* file_actions, int fd, const char *restrict __path, int flags, mode_t mode);
    /**
    * same as posix_spawn_file_actions_adddup2 but handle errors.
    */
    void posix_spawn_wrapper_file_actions_adddup2(posix_spawn_file_actions_t *__file_actions,int __fd, int __newfd);
    /**
    * same as posix_spawn_file_actions_addclose but handle errors.
    */
    void posix_spawn_wrapper_file_actions_addclose(posix_spawn_file_actions_t *__file_actions,int __fd);
    /**
    * same as posix_spawnp but handle errors.
    */
    void posix_spawnp_wrapper(pid_t *__pid, const char *__file,
                        const posix_spawn_file_actions_t *__file_actions,
                        const posix_spawnattr_t *__attrp, char *const __argv[],
                        char *const __envp[]);
#endif
