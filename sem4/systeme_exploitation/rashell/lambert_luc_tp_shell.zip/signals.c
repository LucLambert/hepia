#include "signals.h"

#define MAX_CHILD 1000

static pid_t p_state;
static pid_t p_childs[MAX_CHILD];
static int p_childs_count=0;
static int background_childs_count=0;

/**
* @return nbr of childs process in background
*/
int signals_background_childs_nbr(){
    return background_childs_count;
}

/**
* add child background pid to static global tab of pid wich will be used to handle background job.
* @param p child process pid
*/
void signals_add_background_childs(pid_t p __attribute__((unused))){
    background_childs_count++;
}

/**
* set static global variable p_state equal to p. It will be used to handle process death.
* @param p child process pid
*/
void signals_set_p_state(pid_t p){
    p_state=p;
}

/**
* add child pid to static global tab of pid wich will be used to destroy all childs on close.
* @param p child process pid
*/
void signals_add_p_childs(pid_t p){
    p_childs[p_childs_count++]=p;
}

/**
* remove previously added child pid. 
* @param p child process pid
*/
void signals_remove_p_childs(pid_t p __attribute__((unused))){
    p_childs_count--;
}

/**
* send signals SIGHUP to all childs added previously. 
*/
void signals_kill_all_childs(){
    
    for (int i=0; i<p_childs_count; i++) {
        if(kill(p_childs[i], SIGHUP)==-1)
            die_errno("failed kill");
    }
}

/**
* handler when process receive SIGINT or SIGHUP or SIGCHLD signals.
* SIGINT do nothing. let main handle interrupted process
* SIGHUP send SIGHUP to all childs process
*/
static void handle_sig(int sig, siginfo_t* si, void* data __attribute__((unused))){
    int wstatus;
    switch (sig) {
        case SIGINT:
            break;
        case SIGHUP:
            for (int i=0; i<p_childs_count; i++) {
                if(kill(p_childs[i], SIGHUP)==-1)
                    die_errno("failed kill");
            }
            exit(EXIT_SUCCESS);
        case SIGCHLD:
            if(p_state!=si->si_pid && si->si_status != 127 ){ // if background and execve didn't failed.
                if(waitpid(si->si_pid, &wstatus, WUNTRACED | WCONTINUED)==-1){
                    die_errno("failed wait pid");
                }
                p_childs_count--;
                background_childs_count--;
                if (WIFEXITED(wstatus)) {
                    printf("\nBackground job exited with code %d\n",si->si_status);
                }
            }
            break;
    }
}

/**
* Init struct sigaction to ignore SIGTERM and SIGQUIT signals
* and set handler for SIGINT,SIGHUP and SIGCHLD 
*/
void signals_init(){
    struct sigaction sa;
    sa.sa_flags=SA_SIGINFO|SA_RESTART;

    //ignore SIGTERM and SIGQUIT
    sa.sa_handler=SIG_IGN;
    if(sigemptyset(&sa.sa_mask) == -1)
        die_errno("failed sigemptyset");
    if(sigaddset(&sa.sa_mask, SIGTERM) == -1)
        die_errno("failed sigaddset");
    if(sigaddset(&sa.sa_mask, SIGQUIT) == -1)
        die_errno("failed sigaddset");

    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        die_errno("failed sigaction");
    }
    if (sigaction(SIGQUIT, &sa, NULL) == -1) {
        die_errno("failed sigaction");
    }
    
    //handle SIGINT SIGHUP SIGCHLD
    sa.sa_sigaction=handle_sig;
    if(sigemptyset(&sa.sa_mask)==-1)
        die_errno("failed sigemptyset");
    if(sigaddset(&sa.sa_mask, SIGINT)==-1)
        die_errno("failed sigaddset");
    if(sigaddset(&sa.sa_mask, SIGHUP)==-1)
        die_errno("failed sigaddset");
    if(sigaddset(&sa.sa_mask, SIGCHLD)==-1)
        die_errno("failed sigaddset");
    
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        die_errno("failed sigaction");
    }
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        die_errno("failed sigaction");
    }
    if (sigaction(SIGHUP, &sa, NULL) == -1) {
        die_errno("failed sigaction");
    }
}