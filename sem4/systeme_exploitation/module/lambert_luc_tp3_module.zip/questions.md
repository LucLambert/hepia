## Q1. Implémenter un court programme qui effectue un read de 50 caratères sur /dev/abcd. Quelle est la valeur retournée. Pourquoi ?

La valeur retournée est l'alphabet. Car on veut lire 50 caractères, mais notre driver va stopper l'opération lorsque l'on va essayé de lire plus de  26 caractères. Il va copier les 26 caractères dans le buffer de l'utilisateur puis retourner le nombre de caractères copier. Or vu que notre programme utilisateur ne vais qu'un seul appel à la fonction read on obtient juste l'alphabet.

## Q2. Tester la commande cat /dev/abcd. La lecture devrais se faire de manière continue. Pourquoi ? Quelle fonction C de lecture est utilisée par cat ? Que fais cette fonction ?

Je supposse que la commande cat effectue en boucle en appel à la fonction read, avec une lecture d'un grand nombre de bytes, tant que la valeur retourné par read est différente de 0. Or notre programme renvoie dans ce cas toujours 26 donc cat renvoie indéfiniment l'alphabet.

## Q3. Essayer de lancer la commande cat /dev/abcd deux fois dans deux terminaux différents. Observez-vous des conflits de lecture ? Pourquoi ?

Je n'observe pas de conflit de lecture, car je suppose que les canaux sont multipliés lors d'une nouvelle ouverture sur le périphérique.


## Q4. Implémenter un court programme qui effectue un write de 50 cacatères sur /dev/abcd. Quelle est la valeur retournée. Pourquoi ?

La valeur retournée par la fonction write est 26. On a donc écrit les 26 premiers caractères de notre chaîne dans le périphérique. Ce qui a pour effet de modifier sa valeur par ces 26 caractères car la réponse à l'appel système write est implémenté de la manière que celui du read, c'est à dire lorsque l'on dépasse les 26 caractères on arrete l'opération.


## Q5. Tester la commande *echo ceci est une longue chaine de plus de 24 char > /dev/abcd*. Quel est le résultat ? Pourquoi ?

Le résultat est que maintenant lorsque on lit la valeur du périphérique abcd on obtient "chaine de plus de 24 char". J'ai du mal a expliquer pourquoi le résultat n'est pas "ceci est une longue chaine " car l'opération d'écriture effectuer par echo devrait être stopper par notre périphérique lorsque l'on copie les 26 premiers caractères et non pas les 26 derniers.

## Q6. Tracer la commande ci-dessus avec strace. La commande fait-elle plusieurs appels systèmes write ? Pourquoi ?

## Q7. Essayer de lancer la commande echo ci-dessus deux fois dans deux terminaux différents. Observez-vous des conflits d’écriture ? Pourquoi ?

Je n'observe à nouveau aucun conflit pour les mêmes raison que la Q3.

## Q8. tester à nouveau la commande echo comme indiqué dans la question 7. Qu’observez-vous et pourquoi ?

On observe qu'il n'y a aucun changement sur la chaîne de charactère de base lorsque l'on lit celle-ci car les 26 lettres du buffers sont initialisés lors de l'ouverture du device. On lit donc l'alphabet à chaque fois.

## Q9. implémenter un court programme qui ouvre le fichier de périphérique puis duplique le descripteur de fichier. Vérifier que: (i) lorsque l’on écrit sur un descripteur la modification est perçue par l’autre; (ii) la mémoire n’est pas libérée avant de fermer les deux descripteurs.

i) Lorsque l'on écrit sur un descripteur la modification est perçu par l'autre car si on écrit A. Et que l'on lis 2 fois de suite les 26 caractères on s'aperçoit que la deuxieme contient la modification.

ii) la mémoire est libérée dès lors que l'on ferme un des deux descripteurs.