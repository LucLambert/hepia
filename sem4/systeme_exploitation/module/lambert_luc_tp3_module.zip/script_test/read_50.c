#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(){
    int fd = open("/dev/abcd",O_RDONLY);
    if(fd == -1){
        fprintf(stderr, "open failed\n");
        return -1;
    }
    char alpha[50];
    int status;
    status = read(fd, &alpha, 50);
    if(status == -1){
        perror("read failed : ");
    }

    if(close(fd)==-1)
        perror("close failed : ");

    for (int i=0; i<status; i++) {
        printf("%c", alpha[i]);
    }
    printf("\n");
    return 0;
}