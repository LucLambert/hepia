#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

int main(){
    int fd = open("/dev/abcd",O_RDWR);
    if(fd == -1){
        fprintf(stderr, "open failed\n");
        return -1;
    }

    int cp_fd;
    if((cp_fd=dup(fd))==-1){
        perror("dup failed : ");
    }
    printf("fd=%d cp_fd=%d\n",fd,cp_fd);
    if(write(fd,"A",1)==-1){
        perror("write failed :");
    }
    char c[26];
    for (int k=0; k<2; k++) {
        if(read(cp_fd,&c,26)==-1){
            perror("read failed :");
        }
        for (int i=0; i<26; i++) {
            printf("%c", c[i]);
        }
        printf("\n");
    }

    if(close(cp_fd)==-1)
        perror("close failed : ");
    printf("cp_fd closed\n");
    
    if(close(fd)==-1)
        perror("close failed : ");
    printf("fd closed\n");
    

    return 0;
}