#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(){
    int fd = open("/dev/abcd",O_WRONLY);
    if(fd == -1){
        fprintf(stderr, "open failed\n");
        return -1;
    }
    char alpha[50] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwx";
    int status;
    status = write(fd, alpha, 50);
    if(status == -1){
        perror("write failed : ");
    }

    if(close(fd)==-1)
        perror("close failed : ");

    printf("\n");
    return 0;
}