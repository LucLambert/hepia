#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <asm/uaccess.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Lambert Luc <luc.lambert@etu.hesge.ch>");
MODULE_DESCRIPTION("abcd module");
MODULE_VERSION("0.1");


// Operation prototypes
static int dev_open(struct inode *inode, struct file *filp);
static int dev_release(struct inode *inode, struct file *filp);
static ssize_t dev_read(struct file *filp, char __user *buff, size_t len, loff_t *f_pos);
ssize_t dev_write(struct file *filp, const char __user *buff, size_t len, loff_t *f_pos);


struct abcd_device {
    char* buff; /* ou tout autre données que l'on souhaite */
	int buff_size;
    struct cdev mycdev;
};


// The driver's file operations
static struct file_operations fops = {
	.owner = THIS_MODULE,
	.open = dev_open,
	.read = dev_read,
	.write = dev_write,
	.release = dev_release,
	.llseek = no_llseek,
};

// //global variables
static dev_t devt;
static int status;
static struct abcd_device mydev;

static int buff_size = 26;
module_param(buff_size, int, S_IRUGO);

/**
 * Driver initialization code. 
 */
static int cpt;
static int __init abcd_dev_init(void){

	//register device
    status = alloc_chrdev_region(&devt, 0, 1, "abcd");
    if(status != 0){
        pr_err("device register failed\n");
        return status;
    }

	//init device
	cdev_init(&(mydev.mycdev), &fops);

	devt = MKDEV(MAJOR(devt),MINOR(devt));

	//add device
	status = cdev_add(&mydev.mycdev, devt, 1);
	if(status != 0){
		unregister_chrdev_region(devt, 1);
        pr_err("device add failed\n");
        return status;
    }

	pr_err("abcd initiate\n");
	return 0;
}
module_init(abcd_dev_init);

/**
 * This function is called when the module is unloaded.
 */
static void __exit abcd_dev_exit(void){

	cdev_del(&(mydev.mycdev));
	unregister_chrdev_region(devt, 1);
    pr_err("abcd : driver destroyed\n");
}
module_exit(abcd_dev_exit);


/**
 * Open operation
 */
static int dev_open(struct inode *inode, struct file *filp){
	nonseekable_open(inode, filp);
	mydev.buff_size = buff_size;
	mydev.buff = kmalloc(mydev.buff_size,GFP_KERNEL);
	if(mydev.buff == NULL){
        pr_err("abcd : device alloc failed\n");
	}
	
	cpt =0;
	while(cpt<mydev.buff_size){
		mydev.buff[cpt]=97+cpt;
		cpt++;
	}
	pr_err("abcd: device opened\n");
	return 0;
}

/**
 * Close operation
 */
static int dev_release(struct inode *inode, struct file *filp){
	pr_err("abcd: device closed\n");
	kfree(mydev.buff);
	pr_err("abcd: device memory freed\n");
	return 0;
}

/**
 * Read operation
 */
static int tmp_r;
static ssize_t dev_read(struct file *filp, char __user *buff, size_t len, loff_t * f_pos){
	if(*f_pos + len >= mydev.buff_size){
		if(copy_to_user(buff, &mydev.buff[*f_pos], mydev.buff_size - *f_pos) != 0)
			return -1;
		tmp_r = *f_pos;
		*f_pos=0;
		return mydev.buff_size - tmp_r;
	}else{
		if(copy_to_user(buff, &mydev.buff[*f_pos], len) != 0)
			return -1;
		*f_pos = (*f_pos+len % mydev.buff_size);
		return len;
	}
}

/**
 * Write operation
 */
static int tmp_w;
ssize_t dev_write(struct file *filp, const char __user *buff, size_t len, loff_t *f_pos){
	if(*f_pos + len >= mydev.buff_size){
		if(copy_from_user(&mydev.buff[*f_pos], buff, mydev.buff_size - *f_pos) != 0)
			return -1;
		tmp_w = *f_pos;
		f_pos=0;
		return mydev.buff_size - tmp_w;
	}else{
		if(copy_from_user(&mydev.buff[*f_pos], buff, len) != 0)
			return -1;
		*f_pos = (*f_pos+len % mydev.buff_size);
		return len;
	}	
}