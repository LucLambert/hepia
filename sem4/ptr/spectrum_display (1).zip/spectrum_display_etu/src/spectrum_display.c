/**
 * Name        : spectrum_display.c
 * Date        : 10.10.2018
 * Description : template of real time spectrum display of microphone sound
 */

#include <cr_section_macros.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "LPC17xx.h"
#include "ethmac.h"
#include "lcd.h"
#include "adc.h"
#include "debug.h"
#include "dma_handler.h"

#define BUF_SIZE 4032							// 63*64 samples
#define NB_OF_FREQ 32
#define FS 16000
#define PI 3.14159265359
#define BAR_WIDTH (LCD_MAX_WIDTH/NB_OF_FREQ)
#define BAR_HEIGHT 240							// maximum display bar height (from screen bottom)

volatile int flag=0, buf_idx=0;
__DATA(RAM2) uint16_t buffer[2*BUF_SIZE];       // acquisition double buffer

extern uint16_t sig_ref[];						// this signal can be used for TFD debugging instead of real time acquisition

static void setup_peripherals(void)
{
	ethernet_power_down();						// limit sound noise
	init_lcd();
	clear_screen(LCD_BLACK);
}

// Display the spectrum (to be filled)
// Parameter: spectrum_max_value: current maximum spectrum value to be considered for display
void display(int32_t spectrum_max_value)
{

}

// callback function called at the end of BUF_SIZE sample acquisition
// Parameter: buf_index: 0 or 1, indicating the buffer that as been just filled
void buffer_filled(int buf_index)
{
	buf_idx=buf_index;
	LPC_GPDMACH1->DMACCConfig=0;   // stop sample acquisition (DMA 1): line to be removed !
	flag++;
}


int main(void)
{
	setup_peripherals();
	lcd_print(10,10,BIGFONT, LCD_WHITE, LCD_BLACK, "Sound spectrum");
	lcd_filled_rectangle(100, 200, 100+BAR_WIDTH-1, LCD_MAX_HEIGHT-1, LCD_RED);
	init_adc_dma(0, FS, buffer, BUF_SIZE, buffer_filled);				// launch microphone samples acquisition

	while(!flag);

	int2file("sig.txt", buffer, BUF_SIZE, sizeof(uint16_t), false);		// save signal received (DMA 1 must be stopped to do that)

	return 0;
}
