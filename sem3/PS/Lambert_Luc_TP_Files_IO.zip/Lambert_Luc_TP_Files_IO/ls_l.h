#ifndef LS_FILE_H_
#define LS_FILE_H_

void print_long(char* name);

#endif